package com.example.machineManegement.Service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
@Controller
public class AssetAnalyzer {

	private static final String FILE_PATH = "D:/matrix.txt";

    private Map<String, List<String>> assetMap;
    private Map<String, List<String>> machineMap;
    private ArrayList parent = new ArrayList<>();
    public AssetAnalyzer() throws IOException {
        this.assetMap = new HashMap<>();
        this.machineMap = new HashMap<>();
        File file = new File(FILE_PATH);
        FileReader reader = new FileReader(file);

        BufferedReader bufferedReader = new BufferedReader(reader);
        String line;
        while ((line = bufferedReader.readLine()) != null) {
            String[] tokens = line.split(",");
            String machine = tokens[0];
            String asset = tokens[1];
            String series = tokens[2];
            ArrayList<String> child = new ArrayList<>();
            child.add(machine);
            child.add(asset);
            child.add(series);
            parent.add(child);

            this.assetMap.computeIfAbsent(asset, k -> new ArrayList<>()).add(machine);
            this.machineMap.computeIfAbsent(machine, k -> new ArrayList<>()).add(asset);
        }
        System.out.println("assetMap::::"+assetMap);
        System.out.println("machineMap::::"+machineMap);

        bufferedReader.close();
    }
	
	public List<String> getAssetNamesForMachine(String machineType) {
		System.out.println("Inside getAssetNamesForMachine"+machineMap);
		System.out.println("Inside vlues"+machineMap.get(machineType));
		return this.machineMap.get(machineType);
	}

	public List<String> getMachineTypesForAsset(String assetName) {
		return this.assetMap.get(assetName);
	}

	public List<String> getMachineTypesUsingLatestSeries() {
        List<String> machineTypes = new ArrayList<>();

        for (String machine : this.machineMap.keySet()) {
            boolean isUsingLatestSeriesOfAllAssets = true;

            for (String asset : this.machineMap.get(machine)) {
                String latestSeries = getLatestSeriesOfAsset(asset);
                if (!latestSeries.equals(getSeriesOfAsset(machine, asset))) {
                    isUsingLatestSeriesOfAllAssets = false;
                    break;
                }
            }

            if (isUsingLatestSeriesOfAllAssets) {
                machineTypes.add(machine);
            }
        }

        return machineTypes;
    }

    private String getLatestSeriesOfAsset(String asset) {
        List<String> machines = this.assetMap.get(asset);

        if (machines.size() == 1) {
            return getSeriesOfAsset(machines.get(0), asset);
        } else {
            String latestSeries = null;

            for (String machine : machines) {
                String series = getSeriesOfAsset(machine, asset);
                if (latestSeries == null || latestSeries.compareTo(series) < 0) {
                    latestSeries = series;
                }
            }

            return latestSeries;
        }
    }

    private String getSeriesOfAsset(String machine, String asset) {
    	for(int i=0;i<parent.size();i++)
    	{ArrayList child = (ArrayList) parent.get(i);
    		if(child.get(0).equals(machine)&&child.get(1).equals(asset))
    		{
    			return (String) child.get(2);
    		}
    	}
    	
        return null;
    }


}
