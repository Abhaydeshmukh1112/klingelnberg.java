package com.example.machineManegement.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.machineManegement.Service.AssetAnalyzer;

@RestController
@RequestMapping("/api")
public class AssetAnalyzerController {
	
	@Autowired
    private AssetAnalyzer assetAnalyzer;

    public AssetAnalyzerController(AssetAnalyzer assetAnalyzer) {
        this.assetAnalyzer = assetAnalyzer;
    }

    @GetMapping("/assetNamesForMachine")
    public ResponseEntity<List<String>> getAssetNamesForMachine(@RequestParam String machineType) {
    	System.out.println("Entered in For Machine Method:::::"+machineType);
    	List<String> response = assetAnalyzer.getAssetNamesForMachine(machineType);
    	System.out.println("response For Machine :::::"+response);
        return ResponseEntity.ok().body(response);
    }

    @GetMapping("/machineTypesForAsset")
    public List<String> getMachineTypesForAsset(@RequestParam String assetName) {
        return assetAnalyzer.getMachineTypesForAsset(assetName);
    }

    @GetMapping("/machineTypesUsingLatestSeries")
    public List<String> getMachineTypesUsingLatestSeries() {
        return assetAnalyzer.getMachineTypesUsingLatestSeries();
    }
}


